import random

#Metodo que lanza un dado de seis caras
def lanzar():
    return  random.randint(1,6)

#Define que jugador empieza
def definirTurno(j1,j2,saldoMesa):
    print("la apuesta es de :",saldoMesa )
    
    if(j1<j2):
        print("empieza jugador j2")
        analizarLanzamiento(lanzar(),saldoMesa,apostar(random.randint(1,2)))
        return j2

    elif(j1>j2):
        print("empieza jugador j1")
        analizarLanzamiento(lanzar(),saldoMesa,apostar(random.randint(1,2)))
        return j1

    else:
        print("empate al elegir jugador, nuevo lanzamiento")
        definirTurno(lanzar(),lanzar(),saldoMesa)

 # Proporciona la apuesta minima (saldo de la mesa) 
def apuesta():
    return random.randint(1,10)*100

# Respuesta del jugador (si de sea apostar mas) cuando saca un numero entre 2 y 5
def apostar(desicion):
    if(desicion==1):
        return True
    else:
        return False
#nuevo lanzamiento cuando el jugador decide volver a apostar    
def nuevoLanzamiento(resultado,nuevoResultado, saldoMesa,desicion):
    if(resultado<nuevoResultado):
        print("Ganas de nuevo")
        analizarLanzamiento(nuevoResultado,saldoMesa,desicion)
    else:
        print("Pierdes ",saldoMesa," en tu nuevo intento")
    
#analiza el lanzamiento del jugador en turno
def analizarLanzamiento(dado,saldoMesa,respuesta):
    if(dado>1 & dado<5):
        print("has ganado , puedes intentar jugar de nuevo")
        if(respuesta==True):
            print("has vuelto a apostar")
            
            nuevoLanzamiento(dado,lanzar(),saldoMesa,apostar(random.randint(1,2)))
            
        else:
            print("Te has retirado con",saldoMesa)

    else:
        print("has perdido", saldoMesa)
        
    
    
#desde aqui se ejecuta el juego
def jugar():
    definirTurno(lanzar(),lanzar(), apuesta())
    
    return

jugar()





