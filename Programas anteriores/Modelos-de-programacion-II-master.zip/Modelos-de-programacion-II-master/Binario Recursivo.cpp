/*
Hecho por 
dannyr gustavo garcia cardozo 20152020222
sergio duvan nu�ez sanchez 20161020133
Juan David Neisa 20161020083
*/

#include<iostream>

using namespace std;


void binario(int);
int main(){

int n;// primer numero
cout<<"ingrese el primer numero: ";cin>>n;

binario(n);


	return 0;
}

void binario(int n){
	
	if(n==1){
		cout<<'1';
	}else{
		binario(n/2);
		cout<<n%2;
	}
}

