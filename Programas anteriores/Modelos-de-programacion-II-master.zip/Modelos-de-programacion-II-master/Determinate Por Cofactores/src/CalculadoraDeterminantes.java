//CLASE CALCULADORADETERMINANTE
import javax.swing.JOptionPane;

public class CalculadoraDeterminantes {
    private int[][] matrizA;
    public void asignarTamañoMatriz(int[][] matriz) {
        matrizA = matriz;
    }

    public int[][] CrearCofactores(int columnaPibote, int renglonPibote, int[][] matriz, int tamañoMatriz) {
        int[][] matrizB = new int[tamañoMatriz - 1][tamañoMatriz - 1];
        for (int i = 0; i < (tamañoMatriz - 1); i++) {
            for (int j = 0; j < (tamañoMatriz - 1); j++) {
                if (i < columnaPibote && j < renglonPibote) {
                    matrizB[i][j] = matriz[i][j];
                } else if ((i >= columnaPibote && j >= renglonPibote)) {
                    matrizB[i][j] = matriz[i + 1][j + 1];
                } else {
                    if (i >= columnaPibote) {
                        matrizB[i][j] = matriz[i + 1][j];
                    }
                    if (j >= renglonPibote) {
                        matrizB[i][j] = matriz[i][j + 1];
                    }
                }
            }
        }
        return matrizB;
    }

    public int calcularDeterminante(int[][] matriz, int tamañoMatriz) {

        int determinante = 0;
        int menorDelElemento[] = new int[tamañoMatriz];
        if (tamañoMatriz > 2) {
            for (int i = 0; i < tamañoMatriz; i++) {
                if (i % 2 != 0) {
                    menorDelElemento[i] = menorDelElemento[i] + (matriz[i][0] * calcularDeterminante(CrearCofactores(i, 0, matriz, tamañoMatriz), tamañoMatriz - 1) * (-1));
                } else {
                    menorDelElemento[i] = menorDelElemento[i] + (matriz[i][0] * calcularDeterminante(CrearCofactores(i, 0, matriz, tamañoMatriz), tamañoMatriz - 1));
                }
                determinante = determinante + menorDelElemento[i];
            }
        } else {
            determinante = (matriz[0][0] * matriz[1][1]) - (matriz[0][1] * matriz[1][0]);
        }
        return determinante;
    }
}