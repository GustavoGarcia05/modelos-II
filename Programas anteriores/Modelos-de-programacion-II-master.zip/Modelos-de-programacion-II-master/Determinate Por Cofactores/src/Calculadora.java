/*
Hecho por 
dannyr gustavo garcia cardozo 20152020222
sergio duvan nuñez sanchez 20161020133
Juan David Neisa 20161020083
*/
import javax.swing.JOptionPane;
public class Calculadora {
    public static void main(String[] args) {
        int[][] matriz;
        CalculadoraDeterminantes calculadora = new CalculadoraDeterminantes();
        String tamaño = JOptionPane.showInputDialog("");
        matriz = new int[Integer.valueOf(tamaño)][Integer.valueOf(tamaño)];
        for (int i = 0; i < Integer.valueOf(tamaño); i++) {
            for (int j = 0; j < Integer.valueOf(tamaño); j++) {
                matriz[i][j] = i + 1 * j + 1;
                System.out.print(matriz[i][j] + " ");
            }
            System.out.println("");
        }
        calculadora.asignarTamañoMatriz(matriz);
        JOptionPane.showMessageDialog(null, calculadora.calcularDeterminante(matriz, Integer.valueOf(tamaño)));
    }
}



