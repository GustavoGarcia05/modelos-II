/*
Hecho por 
dannyr gustavo garcia cardozo 20152020222
sergio duvan nu�ez sanchez 20161020133
Juan David Neisa 20161020083
*/

#include<iostream>

using namespace std;

int producto(int, int);

int main(){

int n1;// primer numero
int n2;//segundo numero
int p=0;// producto

cout<<"ingrese el primer numero: ";cin>>n1;


cout<<"\n ingrese el segundo numero: ";cin>>n2;


p=producto(n1,n2);	

cout<<"\n el resultado de la multiplicacion entre "<<n1<<" y "<<n2<<" es: "<<p;
	return 0;
}

int producto(int a, int b){
	int resultado=0;
	int aux,c,d;
  
  c=a;
  d=b;
  for(int i=0;i<d;i++){
  resultado=c+resultado;
  }
	
	 return resultado;
}

